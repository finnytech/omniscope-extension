#!/usr/bin/env python3
"""
OmniScope Universal Official Logo & Icon Distributor
Processes the Nano Banana 2.1 AI-generated official OmniScope OSINT logos
into exact-dimension PNGs and ICOs across:
  1. Chrome Extension (16, 32, 48, 128, 512 + Store Promo Tiles)
  2. OmniScope Web (Cloudflare Pages & Vercel Web: assets/logo.png, favicon.ico, PWA icons)
  3. OmniScope Desktop Windows .exe (Neutralino icon & resources)
  4. OmniScope Android .apk (Launcher icons & web assets)
"""

from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

EMBLEM_SRC = Path(r"C:\Users\Tim\.gemini\antigravity\brain\78214b18-fe1d-4679-a5b9-5474d5d58dba\omniscope_osint_icon_emblem_1792841294028.jpg")
BADGE_SRC = Path(r"C:\Users\Tim\.gemini\antigravity\brain\78214b18-fe1d-4679-a5b9-5474d5d58dba\omniscope_osint_logo_1792841273753.jpg")

EXT_DIR = Path("D:/projects/omniscope-chrome-extension")
WEB_DIR = Path("D:/projects/omniscope-web")
DESKTOP_DIR = Path("D:/projects/omniscope-desktop-neu")
APK_DIR = Path("D:/projects/omniscope-apk")


def make_circular_transparent(img: Image.Image, pad_ratio: float = 0.02) -> Image.Image:
    """Converts square image to RGBA with smooth circular alpha mask around the emblem."""
    img = img.convert("RGBA")
    w, h = img.size
    mask = Image.new("L", (w * 2, h * 2), 0)
    draw = ImageDraw.Draw(mask)
    pad_x = int(w * 2 * pad_ratio)
    pad_y = int(h * 2 * pad_ratio)
    draw.ellipse([pad_x, pad_y, w * 2 - pad_x, h * 2 - pad_y], fill=255)
    mask = mask.resize((w, h), Image.Resampling.LANCZOS)
    out = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    out.paste(img, (0, 0), mask)
    return out


def generate_all():
    emblem_raw = Image.open(EMBLEM_SRC).convert("RGBA")
    badge_raw = Image.open(BADGE_SRC).convert("RGBA")

    emblem_circ = make_circular_transparent(emblem_raw, pad_ratio=0.04)
    badge_circ = make_circular_transparent(badge_raw, pad_ratio=0.01)

    # 1. Chrome Extension Icons (Exact pixel dimensions required by Manifest V3)
    ext_icons = EXT_DIR / "icons"
    ext_icons.mkdir(parents=True, exist_ok=True)
    for sz in (16, 32, 48, 128, 512):
        resized = emblem_circ.resize((sz, sz), Image.Resampling.LANCZOS)
        out_path = ext_icons / f"icon-{sz}.png"
        resized.save(out_path, "PNG")
        print(f"[Chrome Ext] Saved {out_path} ({sz}x{sz})")

    badge_512 = badge_circ.resize((512, 512), Image.Resampling.LANCZOS)
    badge_512.save(ext_icons / "logo-badge-512.png", "PNG")

    # 2. Chrome Web Store Promo Banners
    store_dir = EXT_DIR / "store-assets"
    store_dir.mkdir(parents=True, exist_ok=True)
    for width, height, fname in [
        (440, 280, "promo-small-440x280.png"),
        (1400, 560, "marquee-1400x560.png"),
        (1280, 800, "screenshot-1-1280x800.png"),
    ]:
        canvas = Image.new("RGB", (width, height), (6, 11, 22))
        draw = ImageDraw.Draw(canvas)
        step = 40
        for x in range(0, width, step):
            draw.line([x, 0, x, height], fill=(14, 26, 48), width=1)
        for y in range(0, height, step):
            draw.line([0, y, width, y], fill=(14, 26, 48), width=1)
        draw.rectangle([4, 4, width - 5, height - 5], outline=(16, 185, 129), width=2)

        logo_h = int(min(width, height) * 0.68)
        logo_img = emblem_circ.resize((logo_h, logo_h), Image.Resampling.LANCZOS)
        lx = int(width * 0.05)
        ly = int((height - logo_h) / 2)
        canvas.paste(logo_img, (lx, ly), logo_img)

        tx = lx + logo_h + int(width * 0.04)
        ty = int(height * 0.22)
        try:
            f_lg = ImageFont.truetype("consola.ttf", int(height * 0.10))
            f_md = ImageFont.truetype("consola.ttf", int(height * 0.055))
            f_sm = ImageFont.truetype("consola.ttf", int(height * 0.045))
        except Exception:
            f_lg = ImageFont.load_default()
            f_md = ImageFont.load_default()
            f_sm = ImageFont.load_default()

        draw.text((tx, ty), "OMNISCOPE OSINT", fill=(52, 211, 153), font=f_lg)
        draw.text((tx, ty + int(height * 0.15)), "OFFICIAL CHROME SIDE PANEL v2.6", fill=(56, 189, 248), font=f_md)
        draw.text((tx, ty + int(height * 0.27)), "• Live Doppler Weather Radar Loop", fill=(226, 232, 240), font=f_sm)
        draw.text((tx, ty + int(height * 0.35)), "• USGS Earthquakes & NOAA Tornado Alerts", fill=(226, 232, 240), font=f_sm)
        draw.text((tx, ty + int(height * 0.43)), "• 140+ Weather Models & Box-Scan", fill=(226, 232, 240), font=f_sm)
        draw.text((tx, ty + int(height * 0.51)), "• 100% Keyless Open Data • Zero-Fake", fill=(250, 204, 21), font=f_sm)

        canvas.save(store_dir / fname, "PNG")
        print(f"[Store Asset] Saved {store_dir / fname} ({width}x{height})")

    # 3. OmniScope Web (Cloudflare Pages & Vercel Web)
    web_assets = WEB_DIR / "assets"
    web_assets.mkdir(parents=True, exist_ok=True)
    emblem_circ.resize((512, 512), Image.Resampling.LANCZOS).save(web_assets / "logo.png", "PNG")
    emblem_circ.resize((192, 192), Image.Resampling.LANCZOS).save(web_assets / "icon-192.png", "PNG")
    emblem_circ.resize((512, 512), Image.Resampling.LANCZOS).save(web_assets / "icon-512.png", "PNG")
    emblem_circ.resize((64, 64), Image.Resampling.LANCZOS).save(web_assets / "logo-64.png", "PNG")
    emblem_circ.resize((32, 32), Image.Resampling.LANCZOS).save(web_assets / "favicon-32.png", "PNG")
    badge_512.save(web_assets / "logo-badge.png", "PNG")

    # Save multi-resolution favicon.ico in web root
    ico_img = emblem_circ.resize((256, 256), Image.Resampling.LANCZOS)
    ico_img.save(WEB_DIR / "favicon.ico", format="ICO", sizes=[(16, 16), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)])
    print(f"[Web] Saved logo.png, PWA icons, and {WEB_DIR / 'favicon.ico'}")

    # 4. Desktop Windows App (.exe icon & resources)
    if DESKTOP_DIR.exists():
        desk_res = DESKTOP_DIR / "omniscope-app" / "resources"
        desk_icons = desk_res / "icons"
        desk_icons.mkdir(parents=True, exist_ok=True)
        emblem_circ.resize((256, 256), Image.Resampling.LANCZOS).save(desk_icons / "appIcon.png", "PNG")
        ico_img.save(desk_icons / "appIcon.ico", format="ICO", sizes=[(16, 16), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)])
        print(f"[Desktop] Saved appIcon.png and appIcon.ico in {desk_icons}")

    # 5. Android APK Icons
    if APK_DIR.exists():
        for p in APK_DIR.rglob("*.png"):
            if "ic_launcher" in p.name or "icon" in p.name or "logo" in p.name:
                try:
                    with Image.open(p) as existing:
                        w, h = existing.size
                    emblem_circ.resize((w, h), Image.Resampling.LANCZOS).save(p, "PNG")
                    print(f"[Android APK] Updated icon {p} ({w}x{h})")
                except Exception as e:
                    print(f"[Android APK] Skipped {p}: {e}")


if __name__ == "__main__":
    generate_all()
