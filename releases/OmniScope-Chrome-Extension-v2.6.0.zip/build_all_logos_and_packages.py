import os
import shutil
import zipfile
from PIL import Image

EMBLEM_JPG = r"C:\Users\Tim\.gemini\antigravity\brain\78214b18-fe1d-4679-a5b9-5474d5d58dba\omniscope_osint_icon_emblem_1792841294028.jpg"
BADGE_JPG = r"C:\Users\Tim\.gemini\antigravity\brain\78214b18-fe1d-4679-a5b9-5474d5d58dba\omniscope_osint_logo_1792841273753.jpg"

# 1. Update D:\projects\omniscope-web\index.html with official AI Logo & Favicon
index_path = r"D:\projects\omniscope-web\index.html"
with open(index_path, "r", encoding="utf-8") as f:
    html = f.read()

old_favicon = """<link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><circle cx='50' cy='50' r='45' fill='%23030712' stroke='%2338bdf8' stroke-width='6'/><circle cx='50' cy='50' r='20' fill='none' stroke='%2306b6d4' stroke-width='4'/><line x1='50' y1='5' x2='50' y2='95' stroke='%2338bdf8' stroke-width='3'/><line x1='5' y1='50' x2='95' y2='50' stroke='%2338bdf8' stroke-width='3'/></svg>" />"""
new_favicon = """<link rel="icon" type="image/png" sizes="32x32" href="assets/favicon-32.png" />
    <link rel="shortcut icon" href="favicon.ico" />
    <link rel="apple-touch-icon" sizes="192x192" href="assets/icon-192.png" />"""

if old_favicon in html:
    html = html.replace(old_favicon, new_favicon)
    print("[OK] Replaced inline SVG favicon with official AI logo favicons in index.html")

old_logo_block = """            <div class="ops-logo">
                <span>OMNI</span>SCOPE // WEB
            </div>"""
new_logo_block = """            <div class="ops-logo" style="display:flex;align-items:center;gap:7px;">
                <img src="assets/logo-64.png" alt="OmniScope OSINT Logo" style="width:26px;height:26px;border-radius:6px;border:1px solid rgba(0,240,255,0.5);box-shadow:0 0 8px rgba(0,240,255,0.3);flex-shrink:0;" />
                <div><span>OMNI</span>SCOPE // WEB</div>
            </div>"""

if old_logo_block in html:
    html = html.replace(old_logo_block, new_logo_block)
    print("[OK] Inserted official AI logo into header .ops-logo in index.html")
elif 'src="assets/logo-64.png"' not in html:
    # Handle CRLF variation
    old_crlf = old_logo_block.replace("\n", "\r\n")
    new_crlf = new_logo_block.replace("\n", "\r\n")
    if old_crlf in html:
        html = html.replace(old_crlf, new_crlf)
        print("[OK] Inserted official AI logo into header .ops-logo (CRLF) in index.html")

# Also update OpenGraph preview card with our official AI emblem + badge
og_card_path = r"D:\projects\omniscope-web\assets\omniscope-preview-card.png"
badge_img = Image.open(BADGE_JPG).convert("RGBA")
og_canvas = Image.new("RGBA", (1200, 630), (6, 10, 20, 255))
badge_resized = badge_img.resize((580, 580), Image.Resampling.LANCZOS)
og_canvas.paste(badge_resized, (310, 25))
og_canvas.convert("RGB").save(og_card_path, "PNG", optimize=True)
print("[OK] Updated OpenGraph preview card with official AI logo")

with open(index_path, "w", encoding="utf-8") as f:
    f.write(html)

# 2. Update sync_ecosystem.py to include assets and favicon.ico
sync_script = r"""import os
import shutil

source_root = r'D:\projects\omniscope-web'

targets = [
    r'D:\projects\omniscope-privat\frontend',
    r'D:\projects\omniscope-osint\frontend',
    r'D:\projects\omniscope-desktop-neu\omniscope-app\resources',
    r'D:\projects\omniscope-apk\android_src\assets\web'
]

items_to_sync = [
    ('index.html', 'index.html'),
    ('favicon.ico', 'favicon.ico'),
    ('assets', 'assets'),
    ('css', 'css'),
    ('js', 'js'),
    ('data', 'data'),
    ('plan.md', 'plan.md')
]

for target in targets:
    if not os.path.exists(target):
        continue
    print(f'Syncing to {target}...')
    for src_rel, dst_rel in items_to_sync:
        src_path = os.path.join(source_root, src_rel)
        dst_path = os.path.join(target, dst_rel)
        if not os.path.exists(src_path):
            continue
        if os.path.isdir(src_path):
            if os.path.exists(dst_path):
                shutil.rmtree(dst_path)
            shutil.copytree(src_path, dst_path)
        elif os.path.isfile(src_path):
            shutil.copy2(src_path, dst_path)

print('All ecosystem targets successfully synced with AI Logo & assets!')
"""
with open(r"D:\projects\sync_ecosystem.py", "w", encoding="utf-8") as f:
    f.write(sync_script)

# Execute sync
exec(sync_script)

# 3. Clean sensitive/git artifacts from Neutralino resources before packaging
neu_res = r"D:\projects\omniscope-desktop-neu\omniscope-app\resources"
for junk in [".git", ".wrangler", ".cloudflare", "deploy.ps1", "deploy.bat"]:
    jp = os.path.join(neu_res, junk)
    if os.path.isdir(jp):
        shutil.rmtree(jp, ignore_errors=True)
    elif os.path.isfile(jp):
        os.remove(jp)

# 4. Update Android APK Launcher Icon (ic_launcher.png)
apk_drawable_dir = r"D:\projects\omniscope-apk\android_src\res\drawable"
os.makedirs(apk_drawable_dir, exist_ok=True)
xml_launcher = os.path.join(apk_drawable_dir, "ic_launcher.xml")
if os.path.exists(xml_launcher):
    os.remove(xml_launcher)
    print("[OK] Removed old vector ic_launcher.xml")

emblem_img = Image.open(EMBLEM_JPG).convert("RGBA")
apk_icon = emblem_img.resize((192, 192), Image.Resampling.LANCZOS)
apk_icon_path = os.path.join(apk_drawable_dir, "ic_launcher.png")
apk_icon.save(apk_icon_path, "PNG", optimize=True)
print(f"[OK] Saved new official AI Android icon to {apk_icon_path}")

# 5. Package Chrome Extension v2.6.0 ZIP
ext_root = r"D:\projects\omniscope-chrome-extension"
zip_out_dir = r"D:\projects\releases\chrome"
os.makedirs(zip_out_dir, exist_ok=True)
zip_path = os.path.join(zip_out_dir, "OmniScope-Chrome-Extension-v2.6.0.zip")

exclude_Top = {"generate_assets.py", "build_all_logos_and_packages.py", "store-assets", "CHROMEWEBSTORE.md", ".git", "__pycache__"}

with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
    for root, dirs, files in os.walk(ext_root):
        rel_root = os.path.relpath(root, ext_root)
        first_part = rel_root.split(os.sep)[0]
        if first_part in exclude_Top:
            continue
        for file in files:
            if file in exclude_Top or file.endswith(".pyc"):
                continue
            full_p = os.path.join(root, file)
            arcname = os.path.relpath(full_p, ext_root).replace("\\", "/")
            zf.write(full_p, arcname=arcname)

print(f"[OK] Packaged Chrome Extension ZIP: {zip_path} ({os.path.getsize(zip_path) // 1024} KB)")
